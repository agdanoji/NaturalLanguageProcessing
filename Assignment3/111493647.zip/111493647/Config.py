UNKNOWN = "UNK"
ROOT = "ROOT"
NULL = "NULL"
NONEXIST = -1

max_iter = 5001
batch_size = 10000
hidden_size1 = 300
hidden_size2 = 300
hidden_size3 = 300
embedding_size = 50
learning_rate = 0.1
display_step = 100
validation_step = 200
n_Tokens = 48
lam = 1e-8
